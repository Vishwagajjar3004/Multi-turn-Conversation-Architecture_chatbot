#!/usr/bin/env python3
"""
Multi-turn CLI chatbot powered by the Google Gemini API.

Features
--------
1. Ongoing multi-turn conversation with Gemini.
2. Full conversation history is kept by the SDK's chat session, so Gemini
   remembers everything said so far.
3. `history` - print every message exchanged so far.
4. `clear`   - reset the conversation (wipes history, starts fresh).
5. `save`    - export the conversation to a timestamped JSON file.
6. After every assistant reply, the current total token count (based on
   the real conversation that would be sent on the next turn) is shown.
7. A warning is printed once usage crosses 80% of the model's context
   window, and again (more urgently) past 95%.

Setup
-----
    pip install google-genai
    export GEMINI_API_KEY=your-key-here      # (GOOGLE_API_KEY also works)
    python3 chatbot_gemini.py [--model MODEL] [--context-limit N] [--system "..."]

Commands (type these instead of a message):
    history   show the full conversation
    clear     reset the conversation
    save      export conversation to a JSON file
    help      show available commands
    exit/quit end the session
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

try:
    from google import genai
    from google.genai import types
    from google.genai.errors import APIError
except ImportError:
    print("The 'google-genai' package is required. Install it with:\n"
          "    pip install google-genai --break-system-packages")
    sys.exit(1)


# Context window sizes (input token capacity) for common Gemini models.
# Falls back to DEFAULT_CONTEXT_LIMIT if the chosen model isn't listed.
# NOTE: verify the exact figure for your model in Google AI Studio /
# the Gemini API docs, since these change as new model versions ship.
KNOWN_CONTEXT_LIMITS = {
    "gemini-3.5-flash": 1_000_000,
    "gemini-3.5-pro": 1_000_000,
    "gemini-2.5-flash": 1_000_000,
    "gemini-2.5-pro": 1_000_000,
}
DEFAULT_CONTEXT_LIMIT = 1_000_000
DEFAULT_MODEL = "gemini-3.5-flash"

WARN_THRESHOLD = 0.80
CRITICAL_THRESHOLD = 0.95

HELP_TEXT = """
Available commands:
  history   - show the full conversation so far
  clear     - reset the conversation history
  save      - export the conversation to a JSON file
  help      - show this message
  exit/quit - end the session

Anything else you type is sent to Gemini as a normal message.
""".strip()


class ChatSession:
    def __init__(self, client: "genai.Client", model: str,
                 context_limit: int, system: str | None):
        self.client = client
        self.model = model
        self.context_limit = context_limit
        self.system = system
        self.created_at = datetime.now(timezone.utc)
        self._chat = None
        self._start_chat()

    def _start_chat(self) -> None:
        config = None
        if self.system:
            config = types.GenerateContentConfig(system_instruction=self.system)
        self._chat = self.client.chats.create(model=self.model, config=config)

    # ---------- core conversation logic ----------

    def send_user_message(self, text: str) -> None:
        try:
            response = self._chat.send_message(text)
        except APIError as e:
            print(f"\n[error] API request failed: {e}\n")
            return

        reply_text = response.text or ""
        print(f"\nGemini: {reply_text}\n")
        self._report_token_usage()

    def _count_tokens(self) -> int:
        """Count tokens for the conversation as it currently stands (i.e.
        what would be sent as input on the *next* turn)."""
        history = self._chat.get_history()
        result = self.client.models.count_tokens(model=self.model, contents=history)
        return result.total_tokens or 0

    def _report_token_usage(self) -> None:
        try:
            token_count = self._count_tokens()
        except APIError as e:
            print(f"[warn] Could not count tokens: {e}")
            return

        pct = token_count / self.context_limit
        print(f"[tokens] {token_count:,} / {self.context_limit:,} "
              f"({pct:.1%} of context window used)")

        if pct >= CRITICAL_THRESHOLD:
            print(f"[!!] CRITICAL: You are at {pct:.0%} of the context "
                  f"limit. Consider running 'save' then 'clear' soon, or "
                  f"the next message may be rejected.")
        elif pct >= WARN_THRESHOLD:
            print(f"[!] WARNING: You have used {pct:.0%} of the available "
                  f"context window. Consider saving and clearing soon.")
        print()

    # ---------- commands ----------

    def _history_as_dicts(self) -> list[dict]:
        messages = []
        for content in self._chat.get_history():
            role = content.role
            text = "".join(
                part.text for part in (content.parts or []) if part.text
            )
            messages.append({"role": role, "content": text})
        return messages

    def show_history(self) -> None:
        messages = self._history_as_dicts()
        if not messages:
            print("\n(no messages yet)\n")
            return
        print()
        for i, msg in enumerate(messages, start=1):
            role = "You" if msg["role"] == "user" else "Gemini"
            print(f"{i:>3}. {role}: {msg['content']}")
        print()

    def clear(self) -> None:
        self._start_chat()
        print("\nConversation cleared. Starting fresh.\n")

    def save(self, path: str | None = None) -> str:
        if path is None:
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            path = f"/mnt/user-data/outputs/conversation_{ts}.json"

        os.makedirs(os.path.dirname(path), exist_ok=True)
        payload = {
            "model": self.model,
            "created_at": self.created_at.isoformat(),
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "system": self.system,
            "messages": self._history_as_dicts(),
        }
        with open(path, "w") as f:
            json.dump(payload, f, indent=2)
        print(f"\nConversation saved to: {path}\n")
        return path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Multi-turn Gemini CLI chatbot")
    parser.add_argument("--model", default=DEFAULT_MODEL,
                         help=f"Model to use (default: {DEFAULT_MODEL})")
    parser.add_argument("--context-limit", type=int, default=None,
                         help="Override the context window size in tokens")
    parser.add_argument("--system", default=None,
                         help="Optional system instruction")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    # The SDK auto-detects GEMINI_API_KEY, falling back to GOOGLE_API_KEY
    # if both are set GOOGLE_API_KEY takes precedence, so check either.
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        print("Set the GEMINI_API_KEY (or GOOGLE_API_KEY) environment "
              "variable before running.\n"
              "  export GEMINI_API_KEY=your-key-here")
        sys.exit(1)

    client = genai.Client(api_key=api_key)
    context_limit = args.context_limit or KNOWN_CONTEXT_LIMITS.get(
        args.model, DEFAULT_CONTEXT_LIMIT
    )
    session = ChatSession(client, args.model, context_limit, args.system)

    print("=" * 60)
    print(f"Gemini CLI Chatbot  (model: {args.model})")
    print(f"Context limit: {context_limit:,} tokens")
    print("Type 'help' to see available commands.")
    print("=" * 60)

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue

        cmd = user_input.lower()

        if cmd in ("exit", "quit"):
            print("Goodbye!")
            break
        elif cmd == "help":
            print("\n" + HELP_TEXT + "\n")
        elif cmd == "history":
            session.show_history()
        elif cmd == "clear":
            session.clear()
        elif cmd == "save":
            session.save()
        else:
            session.send_user_message(user_input)


if __name__ == "__main__":
    main()